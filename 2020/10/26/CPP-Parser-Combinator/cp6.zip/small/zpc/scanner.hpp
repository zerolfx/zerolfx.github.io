#ifndef ZPC_SCANNER_HPP
#define ZPC_SCANNER_HPP

#include "helper.hpp"

//class Scanner : public std::string_view {
//  Scanner(std::string_view& in): std::string_view(in) {}
//
//};

#endif //ZPC_SCANNER_HPP
